!!!!!!!!! Finite Element Analysis Assignment !!!!!!!!!
July 2023
------------------------------------------------------------
--- Members: Joel Serrao 230897, Zampieri Giorgio 229205 ---
------------------------------------------------------------

CONTENTS:

-> Report

-> Each folder contains the .txt of batch commands and a database with the solution.

-> Pressure model by Zampieri, Torque model by Serrao. For everything else the efforts were shared.

-> Drawings folder -> 2D drawings of the assembly components + 3D pdf of assembly containing the .STEP info (allows to isolate subcomponents)